# 🚨 Intrusion Detection System - CTI-Based ANN Approach

This project is a GUI-based desktop application that uses Artificial Neural Networks (ANN) for cyber threat detection. It supports dataset uploads, real-time prediction, data visualization, and secure user login.

## 🔍 Features
- Upload CSV threat datasets
- Train ANN model using scikit-learn
- Predict cyber threat levels (e.g., DoS, probe)
- Generate pie charts and heatmaps for analysis
- User login and password management
- Clean, interactive Tkinter GUI

## 🛠️ Tech Stack
- Python 3.x
- Tkinter
- Pandas, NumPy
- Scikit-learn (MLPClassifier)
- Matplotlib, Seaborn
- PIL (for image rendering)
- JSON (user login system)

## ▶️ How to Run
```bash
pip install -r requirements.txt
python project.py
```

## 📊 Outputs
- Pie chart: shows threat category distribution
- Heatmap: shows feature correlations
- Real-time prediction: displayed after user inputs values

## 📌 Future Enhancements
- Add real-time threat feeds
- Cloud-based deployment
- Email alerts on high-risk predictions

## 📄 License
MIT License
